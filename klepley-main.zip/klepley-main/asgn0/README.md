## Assignment 0 directory

This directory contains source code and other files for Assignment 0.

# Split
split.c is a program that takes a delimiter and an arbitray number of files and splits
the file each time the delimeter is found while getting rid of said delimiter. Type './split <delimiter> <file1> ..<filen>' to run the program.

# Makefile
The makefile simply makes the file. Run 'make' to make the split.c program. Run 'clean' to
remove all binaries and basically reset the file. Run 'format' to clang format the file. Run
'make all' do all the things mentioned above at once.

# testfiles and testscripts
This folder holds the files and scripts used for testing in order to esnure working
functionality of the split.c program.

# README.md
This is simply the file you are reading now 

# CODE INSPO / HELP
I basically live in OH, so any help I get on the assignment stems from the TA's
themselves as well as from Prof Veen.
