## Assignment 1 directory
This directory contains source code and other files for Assignment 1.

# Split
memory.c is a program that takes a command from stdin and carries out the command
in the current working directory. this command will either be "get" or "set".

# Makefile
The makefile simply makes the file. Run 'make' to make the split.c program. Run 'make clean' to
remove all binaries and basically reset the file. Run 'format' to clang format the file. Run
'make all' do all the things mentioned above at once.

# Testfiles and Testscripts
These folders hold the files and scripts used for testing in order to esnure working
functionality of the memory.c program.

# README.md
This is simply the file you are reading now! (Awesome Sauce) 

# CODE INSPO / HELP
I basically live in OH, so any help I get on the assignment stems from the TA's
themselves as well as from Prof Veen. Also looked at C documentation and forums online.
